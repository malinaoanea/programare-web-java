package com.example.onlineshopnew.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProductTest {

    @Test
    void getCategory() {
    }

    @Test
    void setCategory() {
    }

    @Test
    void getId() {
    }

    @Test
    void setId() {
    }
}