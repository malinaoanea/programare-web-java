package com.example.onlineshopnew.mapper;

import com.example.onlineshopnew.dto.LotDto;
import com.example.onlineshopnew.model.Lot;
import org.springframework.stereotype.Component;

@Component
public class LotMapper {
    public LotDto lotToDto(Lot lot) {
        return LotDto.builder()
                .number(lot.getNumber())
                .id(lot.getId())
                .build();
    }

    public Lot mapToEntity(LotDto lotDto) {
        return Lot.builder()
                .id(lotDto.getId())
                .number(lotDto.getNumber())
                .build();
    }
}
